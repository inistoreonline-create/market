
<?php
session_start();
require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

// Get featured products
$query = "SELECT p.*, u.username FROM products p JOIN users u ON p.seller_id = u.id WHERE p.status = 'active' ORDER BY p.created_at DESC LIMIT 6";
$stmt = $db->prepare($query);
$stmt->execute();
$featured_products = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-body text-center">
                    <h1 class="display-4"><i class="fas fa-gamepad text-warning"></i> GameMarket</h1>
                    <p class="lead">The ultimate marketplace for gamers - Buy, Sell, and Trade gaming items!</p>
                    <?php if (!isset($_SESSION['user_id'])): ?>
                    <a href="register.php" class="btn btn-primary btn-lg me-2">Join Now</a>
                    <a href="marketplace.php" class="btn btn-outline-primary btn-lg">Browse Items</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <h2 class="mb-4">Featured Items</h2>
        </div>
    </div>

    <div class="row">
        <?php foreach ($featured_products as $product): ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <img src="uploads/<?= $product['image'] ?? 'placeholder.jpg' ?>" class="card-img-top" alt="<?= htmlspecialchars($product['title']) ?>" style="height: 200px; object-fit: cover;">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($product['title']) ?></h5>
                    <p class="card-text"><?= htmlspecialchars(substr($product['description'], 0, 100)) ?>...</p>
                    <p class="card-text"><strong>$<?= number_format($product['price'], 2) ?></strong></p>
                    <p class="card-text"><small class="text-muted">by <?= htmlspecialchars($product['username']) ?></small></p>
                </div>
                <div class="card-footer">
                    <a href="product.php?id=<?= $product['id'] ?>" class="btn btn-primary">View Details</a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
