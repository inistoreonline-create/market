
<?php
class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    private $port;
    public $conn;

    public function __construct() {
        $database_url = $_ENV['DATABASE_URL'] ?? getenv('DATABASE_URL');
        if ($database_url) {
            $db_parts = parse_url($database_url);
            $this->host = $db_parts['host'];
            $this->db_name = ltrim($db_parts['path'], '/');
            $this->username = $db_parts['user'];
            $this->password = $db_parts['pass'];
            $this->port = $db_parts['port'];
        }
    }

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO(
                "pgsql:host=" . $this->host . ";port=" . $this->port . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        return $this->conn;
    }
}
?>
